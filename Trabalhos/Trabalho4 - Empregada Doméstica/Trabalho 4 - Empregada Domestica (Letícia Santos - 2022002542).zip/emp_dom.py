from abc import ABC, abstractmethod

class EmpDomestica(ABC):
    def __init__(self, nome, telefone):
        self.__nome = nome
        self.__telefone = telefone
    
    def getNome(self):
        return self.__nome
    
    def setNome(self, nome):
        self.__nome = nome

    def getTelefone(self):
        return self.__telefone
    
    def setTelefone(self, telefone):
        self.__telefone = telefone

    @abstractmethod
    def getSalario(self):
        pass

class Horista(EmpDomestica):
    def __init__(self, nome, telefone, horasTrabalhadas, valorHora):
        super().__init__(nome, telefone)
        self.__horasTrabalhadas = horasTrabalhadas
        self.__valorHora = valorHora
    
    def getHorasTrabalhadas(self):
        return self.__horasTrabalhadas
    
    def getValorHora(self):
        return self.__valorHora
    
    def getSalario(self):
        return self.__horasTrabalhadas * self.__valorHora
    
class Diarista(EmpDomestica):
    def __init__(self, nome, telefone, diasTrabalhados, valorDia):
        super().__init__(nome, telefone)
        self.__diasTrabalhados = diasTrabalhados
        self.__valorDia = valorDia
    
    def getDiasTrabalhados(self):
        return self.__diasTrabalhados
    
    def getValorDia(self):
        return self.__valorDia
    
    def getSalario(self):
        return self.__diasTrabalhados * self.__valorDia
    
class Mensalista(EmpDomestica):
    def __init__(self, nome, telefone, salario):
        super().__init__(nome, telefone)
        self.__salario = salario
    
    def getSalario(self):
        return self.__salario

if __name__ == "__main__":
    empHorista = Horista('Maria', 35999887766, 160, 12)
    empDiarista = Diarista('Ana', 35999554433, 20, 65)
    empMensalista = Mensalista('Carla', 35999443322, 1200)
    empsDomesticas = [empHorista, empDiarista, empMensalista]
    menorSalario = empHorista.getSalario()
    for emp in empsDomesticas:
        print('Nome: {} - Salario: {}'. format(emp.getNome(), emp.getSalario()))
        if (emp.getSalario() < menorSalario):
            menorSalario = emp.getSalario()
            tel = emp.getTelefone()
            nome = emp.getNome()
    
    print('\n----Opção mais barata----\n')
    print('Nome: {}\nTel: {}\nSalário: {}'. format(nome, tel, menorSalario))
    