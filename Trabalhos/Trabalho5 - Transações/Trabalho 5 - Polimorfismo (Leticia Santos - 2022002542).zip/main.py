from abc import ABC, abstractmethod

class Transacao():
    def __init__(self, data, valor, descricao):
        self.data = data
        self.valor = valor
        self.descricao = descricao
    
    @property
    def data(self):
        return self.__data
    
    @data.setter
    def data(self, data):
        self.__data = data
    
    @property
    def valor(self):
        return self.__valor

    @valor.setter
    def valor(self, valor):
        self.__valor = valor
    
    @property
    def descricao(self):
        return self.__descricao

    @descricao.setter
    def descricao(self, descricao):
        self.__descricao = descricao
    
class Conta(ABC):
    def __init__(self, numConta, nome, saldo, listaTransacao) -> None:
        self.__numConta = numConta
        self.__nome = nome
        self.saldo = saldo
        self.__listaTransacao = listaTransacao
    
    @property
    def numConta(self):
        return self.__numConta
    
    @property
    def nome(self):
        return self.__nome
    
    @property
    def saldo(self):
        return self.__saldo

    @saldo.setter
    def saldo(self, saldo):
        self.__saldo = saldo
    
    @property
    def transacoes(self):
        return self.__transacoes
    
    @transacoes.setter
    def transacoes(self, transacoes):
        self.__transacoes = transacoes
    
    @property
    def listaTransacao(self):
        return self.__listaTransacao
    
    def depositarConta(self, deposito, transacoes, data):
        transacoes.data = data
        transacoes.valor = deposito
        transacoes.descricao = 'Depósito'
        self.saldo += deposito
        self.__listaTransacao.append(transacoes)
    
    def retirarConta(self, retirada, transacoes, data):
        if retirada > self.saldo:
            print(f'Não é possível retirar {retirada}')
        else:
            transacoes.data = data
            transacoes.valor = retirada
            transacoes.descricao = 'Retirada'
            self.__listaTransacao.append(transacoes)
        
    @abstractmethod
    def imprimirExtrato(self):
        pass

class ContaPoupanca(Conta):
    def __init__(self, numConta, nome, saldo, listaTransacao, aniverConta):
        super().__init__(numConta, nome, saldo, listaTransacao)
        self.__aniverConta = aniverConta
    
    @property
    def aniverConta(self):
        return self.__aniverConta
    
    def imprimirExtrato(self):
        print('Número da Conta: {}'. format(self.numConta))
        print('Nome Corretista: {}'. format(self.nome))
        print('Saldo: {}'. format(self.saldo))
        print('Aniversário da Conta: {}'. format(self.aniverConta))
        print('****Transações***')
        for list in self.listaTransacao:
            print('Data: {} - Valor: {} - Descrição: {}'. format(list.data, list.valor, list.descricao))
        print()
               
class ContaCorrenteComum(Conta):
    def __init__(self, numConta, nome, saldo, listaTransacao):
        super().__init__(numConta, nome, saldo, listaTransacao)
    
    def imprimirExtrato(self):
        print('Número da Conta: {}'. format(self.numConta))
        print('Nome Corretista: {}'. format(self.nome))
        print('Saldo: {}'. format(self.saldo))
        print('****Transações***')
        for list in self.listaTransacao:
            print('Data: {} - Valor: {} - Descrição: {}'. format(list.data, list.valor, list.descricao))
        print()

class ContaCorrenteLimite(Conta):
    def __init__(self, numConta, nome, saldo, listaTransacao, limite):
        super().__init__(numConta, nome, saldo, listaTransacao)
        self.__limite = limite
    
    @property
    def limite(self):
        return self.__limite
    
    @limite.setter
    def limite(self, limite):
        self.__limite = limite
    
    def retirarConta(self, retirada, transacoes, data):
        if retirada > (self.saldo + self.__limite):
            print(f'Não é possível retirar {retirada}')
        else:
            if retirada < self.saldo:
                transacoes.data = data
                transacoes.valor = retirada
                transacoes.descricao = 'Retirada'
                self.saldo -= retirada
                self.__listaTransacao.append(transacoes)
            else:
                transacoes.data = data
                transacoes.valor = retirada
                transacoes.descricao = 'Retirada'
                self.__limite = (retirada - self.saldo)
                self.saldo = 0
                self.listaTransacao.append(transacoes)
    
    def imprimirExtrato(self):
        print('Número da Conta: {}'. format(self.numConta))
        print('Nome Corretista: {}'. format(self.nome))
        print('Saldo: {}'. format(self.saldo))
        print('Limite: {}'. format(self.limite))
        print('****Transações***')
        for list in self.listaTransacao:
            print('Data: {} - Valor: {} - Descrição: {}'. format(list.data, list.valor, list.descricao))
        print()

if __name__ == "__main__":
    contaP = ContaPoupanca(123, 'Letícia Santos', 4500, [], '03')
    contaCC = ContaCorrenteComum(456, 'Matheus Menezes', 9800, [])
    contaCL = ContaCorrenteLimite(789, 'Flavia Menezes', 2000, [], 200)
    listaContas = [contaP, contaCC, contaCL]
    transacaoP = Transacao('', 0, '')
    transacaoCC = Transacao('', 0, '')
    transacaoCL = Transacao('', 0, '')
    contaP.depositarConta(400, transacaoP, '03/12/2021')
    contaCC.depositarConta(500, transacaoCC, '31/12/2021')
    contaCL.depositarConta(200, transacaoCL, '03/08/2022')
    contaP.imprimirExtrato()
    contaCC.imprimirExtrato()
    contaCL.imprimirExtrato()
    contaP.retirarConta(600, transacaoP, '04/12/2021')
    contaCC.retirarConta(10000, transacaoCC, '02/01/2022')
    contaCL.retirarConta(2500, transacaoCL, '10/09/2022')
    contaP.imprimirExtrato()
    contaCC.imprimirExtrato()
    contaCL.imprimirExtrato()
    